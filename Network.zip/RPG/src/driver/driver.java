package driver;

import controller.Controller;

public class driver {

	public static void main(String[] args){
		Controller controller = new Controller();
		
		controller.start();
	}
}
