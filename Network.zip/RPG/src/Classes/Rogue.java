package Classes;

import abstractClasses.Entity;

public class Rogue extends Entity{

	private int energy;

	
	public Rogue(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	public int getEnergy() {
		return energy;
	}

	public void setEnergy(int energy) {
		this.energy = energy;
	}

	@Override
	public void attack1() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void attack2() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void attack3() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void attack4() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void attack5() {
		// TODO Auto-generated method stub
		
	}
	
	
}
