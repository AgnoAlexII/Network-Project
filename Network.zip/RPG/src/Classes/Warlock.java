package Classes;

import abstractClasses.Entity;

public class Warlock extends Entity{

	private int mana;
	
	public Warlock(String name) {
		super(name);
	}

	public int getMana() {
		return mana;
	}

	public void setMana(int mana) {
		this.mana = mana;
	}

	@Override
	public void attack1() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void attack2() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void attack3() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void attack4() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void attack5() {
		// TODO Auto-generated method stub
		
	}
	
	
}
