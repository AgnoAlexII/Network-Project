package Classes;

import abstractClasses.Entity;

public class Warrior extends Entity{

	private int rage;
	
	public Warrior(String name) {
		super(name);
	}

	public int getRage() {
		return rage;
	}
	
	public void setRage(int rage) {
		this.rage = rage;
	}

	@Override
	public void attack1() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void attack2() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void attack3() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void attack4() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void attack5() {
		// TODO Auto-generated method stub
		
	}
	
}
